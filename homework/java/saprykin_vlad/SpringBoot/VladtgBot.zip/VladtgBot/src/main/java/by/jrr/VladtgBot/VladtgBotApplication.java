package by.jrr.VladtgBot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VladtgBotApplication {

	public static void main(String[] args) {
		SpringApplication.run(VladtgBotApplication.class, args);
	}

}
