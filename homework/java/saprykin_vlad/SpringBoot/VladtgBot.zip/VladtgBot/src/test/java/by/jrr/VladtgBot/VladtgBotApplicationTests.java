package by.jrr.VladtgBot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VladtgBotApplicationTests {

	@Test
	void contextLoads() {
	}

}
